import time 
import os 
import random 
   
   
class Matrix: 
    def __init__(self, col=0, heigth=30): 
        self.heigth = heigth 
        self.headcolor = 37 # white 
        self.bodycolor = 32 # green 
        self.bgcolor = 40 # black 
        self.col = col 
        self.raw = random.randrange(self.heigth) 
        self.lenth = random.randrange(self.heigth/2) 
        self.char = '' 
        self.string = """abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890~`!@#$%^&*()-_=+[{]}\|;:'",<.>/?"""
        self.stringlen = len(self.string) 
        self.heightrange = set(range(self.heigth)) 
   
    def fall(self): 
        headraw = self.raw 
        bodyraw = headraw - 1
        tailraw = headraw - self.lenth 
        # print body, repeat the self.char of headdraw in green color.
        if bodyraw in self.heightrange: 
            print '\033[{};{}H\033[{};{}m{}\033[0m'.format(bodyraw, self.col, self.bgcolor, self.bodycolor, self.char) 
        # print head, show a new char in white color.
        if headraw in self.heightrange: 
            self.char = self.getchar()                                                                    
            print '\033[{};{}H\033[{};{}m{}\033[0m'.format(headraw, self.col, self.bgcolor, self.headcolor, self.char) 
        # print tail, erase the char of random steps away
        if tailraw in self.heightrange: 
            print '\033[{};{}H\033[{};{}m \033[0m'.format(tailraw, self.col, self.bgcolor, self.bodycolor) 
        if tailraw == self.heigth: 
            self.raw = - random.randrange(self.heigth) #come back height steps, head and body may be dispeared
            self.lenth = random.randrange(self.heigth/2) 
        else: 
            self.raw += 1
   
    def getchar(self): 
        return self.string[random.randrange(self.stringlen)] 
   
def main(): 
    heigth = 30
    width = 100
    os.system('clear') 
    matrixes = [] 
    for raw in range(heigth): 
        #mov the cursor to {raw,0}, and print ' '*width, refering to wiki/ansi_escape_code
        print '\033[{};0H\033[40;32m{}'.format(raw, ' '*width) 
    for col in range(width): 
        matrix = Matrix(col, heigth) 
        matrixes.append(matrix) 
   
    while True: 
        time.sleep(0.05) 
        for matrix in matrixes: 
            matrix.fall() 
if __name__ == '__main__': 
    main()
