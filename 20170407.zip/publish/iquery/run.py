# -*- coding: utf-8 -*-

from iquery.core import cli


if __name__ == '__main__':
    cli()
