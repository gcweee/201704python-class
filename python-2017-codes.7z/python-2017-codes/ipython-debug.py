def func():
    i=1
    j=0
    print i/j
func()

