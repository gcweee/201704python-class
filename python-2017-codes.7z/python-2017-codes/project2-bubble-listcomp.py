aList = [3,14,0,7,8,22]

def change(alist, pos):
    alist[pos],alist[pos+1] = alist[pos+1],alist[pos]

l = [ change(aList,j) for i in range(len(aList)) for j in range(len(aList)-1)  if aList[j] > aList[j+1]]

print aList
