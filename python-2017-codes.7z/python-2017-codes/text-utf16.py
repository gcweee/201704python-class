f = open('text-utf16.txt')
s = f.read()
snew = s.decode('utf-16')
print s
print snew
