
x = 1
def g():
    import a
    print a.f()

