# -*- coding: gbk -*-
str1 = "���"
print type(str1), str1
