f = open('text-gbk.txt')
s = f.read()
print s
