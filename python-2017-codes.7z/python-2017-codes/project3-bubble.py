#-*- coding: utf-8 -*-
def showList(aList):
    print [item[1] for item in aList]

#可以继续改进：
#1.通过decorator分离显示和排序
#2.通过yield，把bubble变为一个generator
def bubble(aList):
    for i in range(len(aList)):
        beforeList = aList[:]
        for index, item in enumerate(beforeList):
            aList[index]=[index, item[1]]
        #bubble one number
        moved = False
        for j in range(len(aList)-i-1):
            if aList[j][1]<aList[j+1][1]:
                aList[j],aList[j+1] = aList[j+1], aList[j]
                moved = True
        if not moved:
            break
        #show result of one round
        print "--------------------"
        print "before:",; showList(beforeList)
        for index, item in enumerate(aList):
            if item[0] !=index:
                print item[1], "from:", item[0], "to:", index 
        print "after:",; showList(aList)

if __debug__ :
    aList = [[0,3],[0,14],[0,0],[0,7],[0,8],[0,22]]
else:
    aList = []
    i=0
    while True:
        input = raw_input("input a number, space for end:")
        if input == " ":
            break
        aList.append([i, int(input)])
        i += 1

bubble(aList)
