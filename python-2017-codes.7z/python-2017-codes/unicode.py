import codecs

#f = open("words-chs.txt","rb")
f = open("zhong-utf8.txt","rb")
#fc = codecs.EncodedFile(f,'gbk')
#word = fc.readword()
word = f.readline()
f.close()
print "ansi string:",type(word)
print word

uword=word.decode("utf-8")
print "utf-8 string:",type(uword)
print uword

gbkword=uword.encode("gbk")
print "ansi string:",type(gbkword)
print gbkword


ascword=uword.encode("utf-8")
print "ansi string:",type(ascword)
print ascword

