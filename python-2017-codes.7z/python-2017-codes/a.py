import b
def f():
    return b.x

print f()
