f = open('text-utf8.txt')
s = f.read()
snew = s.decode('utf-8')
print s
print snew
