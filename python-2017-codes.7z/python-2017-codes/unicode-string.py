# -*- coding: utf-8 -*-
print u"你好"
