def sum2(value1, value2):
    '''
    Sum value1 and value2
    >>> sum2(10, 2)
    12
    >>> sum2(30, 5)
    35
    '''
    return value1+value2

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

