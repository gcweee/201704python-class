f = open("zhong-utf8.txt","rb")
word = f.readline()
f.close()

print "byte string:",type(word)  #byte string
print word

uword=word.decode("utf-8")
print "utf-8 string:",type(uword)  #byte string --> unicode object
print uword

gbkword=uword.encode("gbk")
print "byte string:",type(gbkword)  #unicode --> byte string
print gbkword

ascword=uword.encode("utf-8")
print "byte string:",type(ascword)  #unicode --> byte string
print ascword


