# -*- coding: utf-8 -*-
str1 = "你好"
print type(str1), str1